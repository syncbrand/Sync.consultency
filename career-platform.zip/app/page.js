import Navbar from "../components/Navbar";
import JobCard from "../components/JobCard";

export default function Home() {
  return (
    <div>
      <Navbar />
      <section className="flex items-center justify-between px-20 py-20">
        <div>
          <h1 className="text-4xl font-bold mb-4">
            Get Hired Faster with Jobs + Referrals + Training
          </h1>
          <button className="bg-primary text-white px-6 py-3 rounded-lg mr-4">
            Find Jobs
          </button>
        </div>
        <div className="w-[400px] h-[300px] bg-gray-200 rounded-lg" />
      </section>
      <section className="grid grid-cols-3 gap-6 px-20 py-16">
        <JobCard />
        <JobCard />
        <JobCard />
      </section>
    </div>
  );
}
