export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body className="bg-light text-dark">{children}</body>
    </html>
  );
}
