module.exports = {
  content: ["./app/**/*.{js,jsx}", "./components/**/*.{js,jsx}"],
  theme: {
    extend: {
      colors: {
        primary: "#2563EB",
        secondary: "#10B981",
        dark: "#111827",
        light: "#F9FAFB",
      },
    },
  },
  plugins: [],
};
