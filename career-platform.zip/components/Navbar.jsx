export default function Navbar() {
  return (
    <nav className="flex justify-between items-center px-20 py-4 bg-white shadow">
      <h1 className="text-xl font-bold text-primary">CareerBoost</h1>
    </nav>
  );
}
