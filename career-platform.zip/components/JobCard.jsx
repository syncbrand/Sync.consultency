export default function JobCard() {
  return (
    <div className="p-6 bg-white rounded-xl shadow">
      <h3 className="text-lg font-semibold">React Developer</h3>
      <p className="text-gray-500">Tech Company • Remote</p>
      <button className="mt-4 bg-primary text-white px-4 py-2 rounded">
        Apply Now
      </button>
    </div>
  );
}
